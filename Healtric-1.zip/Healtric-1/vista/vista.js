document.getElementById('deviceForm').addEventListener('submit', function(e) {
    e.preventDefault();
    
    // Recoger datos del formulario
    var year = document.getElementById('year').value;
    var brand = document.getElementById('brand').value;
    var battery = parseInt(document.getElementById('battery').value);
    var tipsDiv = document.getElementById('tips');
    var tips = "<h2>Tips para el cuidado de tu dispositivo</h2>";
    
    // Tips generales
    tips += "<div class='tip'><strong>Actualiza el sistema:</strong> Mantén siempre actualizado el sistema operativo para un mejor rendimiento y seguridad.</div>";
    tips += "<div class='tip'><strong>Uso de cargadores adecuados:</strong> Emplea siempre cargadores oficiales o recomendados por el fabricante.</div>";
    tips += "<div class='tip'><strong>Limpieza regular:</strong> Limpia la pantalla y el cuerpo del dispositivo para evitar acumulación de suciedad.</div>";
  
    // Tips según el año de lanzamiento
    if (year === "before-2015") {
      tips += "<div class='tip'><strong>Dispositivo antiguo:</strong> Usa versiones ligeras de apps como Facebook Lite, optimiza almacenamiento, usa ROMs personalizadas, reduce procesos en segundo plano y carga con cuidado.</div>";
      tips += "<div class='tip'><strong>Usa versiones ligeras de apps:</strong> Instala versiones 'Lite' de apps como Facebook, Messenger, o usa navegadores en vez de apps pesadas.</div>";
      tips += "<div class='tip'><strong>Optimiza almacenamiento:</strong> Borra archivos innecesarios, usa una microSD si es posible y limpia caché regularmente.</div>";
      tips += "<div class='tip'><strong>Usa ROMs personalizadas:</strong> Si el fabricante dejó de actualizar el sistema, instalar una ROM ligera como LineageOS puede mejorar el rendimiento.</div>";
      tips += "<div class='tip'><strong>Reduce procesos en segundo plano:</strong> Desactiva animaciones, usa fondos estáticos y cierra apps que consumen muchos recursos.</div>";
      tips += "<div class='tip'><strong>Carga con cuidado:</strong> Usa un cargador de buena calidad y evita sobrecalentamiento al cargarlo.</div>";
    } else if (year === "2015-2020") {
      tips += "<div class='tip'><strong>Dispositivo relativamente reciente:</strong> Mantén el sistema actualizado, reemplaza la batería si es necesario, controla las apps en segundo plano, desinstala apps pesadas y cuida el hardware.</div>";
      tips += "<div class='tip'><strong>Mantén el sistema actualizado:</strong> Instala las últimas actualizaciones disponibles para mejorar seguridad y rendimiento.</div>";
      tips += "<div class='tip'><strong>Reemplaza la batería si es necesario:</strong> Si notas que la batería dura muy poco, cambiarla puede dar nueva vida al dispositivo.</div>";
      tips += "<div class='tip'><strong>Controla las apps en segundo plano:</strong> Usa la opción 'Optimización de batería' y desactiva apps innecesarias.</div>";
      tips += "<div class='tip'><strong>Desinstala apps pesadas:</strong> Algunas aplicaciones modernas requieren muchos recursos, mejor usa alternativas más ligeras.</div>";
      tips += "<div class='tip'><strong>Cuida el hardware:</strong> Usa una funda y protector de pantalla para evitar daños físicos.</div>";
    } else if (year === "after-2020") {
      tips += "<div class='tip'><strong>Dispositivo reciente:</strong> Evita sobrecargar la batería, reduce la temperatura, mantén limpio el puerto de carga, no instales apps innecesarias y realiza mantenimiento periódico.</div>";
      tips += "<div class='tip'><strong>Evita sobrecargar la batería:</strong> Mantén la carga entre 20% y 80% para prolongar su vida útil.</div>";
      tips += "<div class='tip'><strong>Reduce la temperatura:</strong> No uses el celular mientras carga y evita exposición prolongada al sol.</div>";
      tips += "<div class='tip'><strong>Mantén limpio el puerto de carga:</strong> La acumulación de polvo puede afectar la conexión y la carga.</div>";
      tips += "<div class='tip'><strong>No instales apps innecesarias:</strong> Cada app consume almacenamiento y recursos, instala solo lo esencial.</div>";
      tips += "<div class='tip'><strong>Realiza mantenimiento periódico:</strong> Borra archivos basura, revisa apps en segundo plano y reinicia el celular al menos una vez a la semana.</div>";
    }
    
    // Tips según la capacidad de la batería
    if (battery < 2000) {
      tips += "<div class='tip'><strong>Batería de baja capacidad:</strong> Evita ciclos de carga extremos y protege el dispositivo del sobrecalentamiento.</div>";
    } else {
      tips += "<div class='tip'><strong>Batería de mayor capacidad:</strong> Aunque tengas más mAh, no olvides evitar cargas prolongadas y temperaturas extremas.</div>";
    }
    
    // Tips según la marca del dispositivo
    if (brand === "samsung") {
      tips += "<div class='tip'><strong>Consejo para Samsung:</strong> Mantén One UI actualizado, usa el modo de mantenimiento, habilita 'Cuidado del dispositivo', desactiva Bixby si no lo usas, evita sobrecalentar el Exynos/Snapdragon, y activa la protección de batería.</div>";
      tips += "<div class='tip'><strong>Mantén One UI actualizado:</strong> Samsung ofrece soporte prolongado en modelos recientes. Ve a Ajustes > Actualización de software y verifica si hay nuevas versiones.</div>";
      tips += "<div class='tip'><strong>Usa el modo de mantenimiento:</strong> En Samsung Members, activa el Modo de mantenimiento antes de llevarlo a reparar, para proteger tu información.</div>";
      tips += "<div class='tip'><strong>Habilita 'Cuidado del dispositivo':</strong> Ve a Ajustes > Cuidado del dispositivo para optimizar batería, almacenamiento y RAM automáticamente.</div>";
      tips += "<div class='tip'><strong>Desactiva Bixby si no lo usas:</strong> Si no usas Bixby, desactívalo desde Ajustes > Funciones avanzadas para liberar recursos.</div>";
      tips += "<div class='tip'><strong>Evita sobrecalentar el Exynos/Snapdragon:</strong> No juegues mientras cargas y usa fundas que disipen bien el calor.</div>";
      tips += "<div class='tip'><strong>Activa la protección de batería:</strong> En modelos recientes, Ajustes > Cuidado de la batería > Protección de la batería para limitar la carga al 85% y prolongar la vida útil.</div>";
    } else if (brand === "iphone") {
      tips += "<div class='tip'><strong>Consejo para iPhone:</strong> Actualiza siempre iOS, usa el 'Modo de batería optimizada', cierra apps innecesarias solo si consumen recursos, evita temperaturas extremas, limpia el puerto Lightning, y usa accesorios certificados (MFi).</div>";
      tips += "<div class='tip'><strong>Actualiza siempre iOS:</strong> Apple ofrece soporte de hasta 6 años en algunos modelos, mantente al día con las actualizaciones.</div>";
      tips += "<div class='tip'><strong>Usa el 'Modo de batería optimizada':</strong> Ve a Ajustes > Batería > Salud de la batería y activa la opción para reducir el desgaste.</div>";
      tips += "<div class='tip'><strong>Cierra apps innecesarias solo si consumen recursos:</strong> iOS gestiona bien la RAM, pero si una app da problemas, ciérrala desde la multitarea.</div>";
      tips += "<div class='tip'><strong>Evita temperaturas extremas:</strong> Los iPhones sufren más con el calor y el frío, evita exponerlos al sol o dejarlos en el auto.</div>";
      tips += "<div class='tip'><strong>Limpia el puerto Lightning:</strong> Usa aire comprimido o un palillo de madera para evitar que el polvo impida la carga.</div>";
      tips += "<div class='tip'><strong>Usa accesorios certificados (MFi):</strong> Usa cargadores y cables originales o certificados por Apple para evitar daños en la batería.</div>";
    } else if (brand === "xiaomi") {
      tips += "<div class='tip'><strong>Consejo para Xiaomi:</strong> Desactiva apps preinstaladas (bloatware), optimiza MIUI/HyperOS, habilita 'Carga inteligente', desactiva anuncios del sistema, evita actualizaciones de MIUI no estables, y limpia la memoria caché regularmente.</div>";
      tips += "<div class='tip'><strong>Desactiva apps preinstaladas (bloatware):</strong> Xiaomi trae muchas apps preinstaladas. Ve a Ajustes > Aplicaciones y deshabilita las que no uses.</div>";
      tips += "<div class='tip'><strong>Optimiza MIUI/HyperOS:</strong> En Ajustes > Batería y rendimiento, usa el modo 'Ahorro de batería' cuando no necesites potencia máxima.</div>";
      tips += "<div class='tip'><strong>Habilita 'Carga inteligente':</strong> En modelos recientes, limita la carga al 80-90% para prolongar la vida útil de la batería.</div>";
      tips += "<div class='tip'><strong>Desactiva anuncios del sistema:</strong> Ve a Ajustes > Privacidad y desactiva recomendaciones personalizadas para mejorar rendimiento.</div>";
      tips += "<div class='tip'><strong>Evita actualizaciones de MIUI no estables:</strong> Algunas actualizaciones pueden traer bugs. Revisa foros antes de actualizar o usa la versión estable.</div>";
      tips += "<div class='tip'><strong>Limpia la memoria caché regularmente:</strong> Ve a Ajustes > Almacenamiento y borra caché de apps para mejorar velocidad.</div>";
    }
    
    // Mostrar los tips en la página
    tipsDiv.innerHTML = tips;
});

function ingreso() {
  window.location.href = "../login/login.html";
}