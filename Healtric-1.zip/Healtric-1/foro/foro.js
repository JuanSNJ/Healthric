document.addEventListener('DOMContentLoaded', function() {
    const postForm = document.getElementById('postForm');
    const postsContainer = document.getElementById('posts');

    // Sample initial posts
    const initialPosts = [
        {
            title: 'Alguien sabe de alguna rom para mi xiaomi redmi note 11?',
            content: 'Quisiera saber de alguna rom que sea liviana para aumentar la vida util de mi equipo',
            author: 'Andres_ZC12',
            time: 'Hace 2 horas'
        },
        {
            title: '¿Que lugar me recomiendan para cambiar la bateria de mi celular? es un iphone 12.',
            content: 'Quiero mejorar la batreria de mi celular para que dure hasta el final del día.',
            author: 'Vanessa-17',
            time: 'Hace 5 horas'
        }
    ];

    // Display initial posts
    initialPosts.forEach(post => createPostElement(post));

    // Handle form submission
    postForm.addEventListener('submit', function(e) {
        e.preventDefault();
        
        const title = document.getElementById('postTitle').value;
        const content = document.getElementById('postContent').value;

        if (title && content) {
            createPostElement({
                title: title,
                content: content,
                author: 'Usuario',
                time: 'Ahora'
            });

            // Clear form
            postForm.reset();
        }
    });

    function createPostElement(post) {
        const postElement = document.createElement('div');
        postElement.className = 'card';
        postElement.innerHTML = `
            <h3>${post.title}</h3>
            <p>${post.content}</p>
            <div class="post-meta">
                <span>Publicado por: ${post.author}</span>
                <span>${post.time}</span>
            </div>
        `;
        postsContainer.insertBefore(postElement, postsContainer.firstChild);
    }
});