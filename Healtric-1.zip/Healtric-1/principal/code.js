document.getElementById("deviceForm").addEventListener("submit", function (e) {
  e.preventDefault();

  // Recoger datos del formulario
  var year = parseInt(document.getElementById("year").value);
  var brand = document.getElementById("brand").value;
  var battery = parseInt(document.getElementById("battery").value);
  var range = document.getElementById("range").value;
  var tipsDiv = document.getElementById("tips");
  var tips = "<h2>Tips para el cuidado de tu dispositivo</h2>";

  // Tips generales
  tips +=
    "<div class='tip'><strong>Actualiza el sistema:</strong> Mantén siempre actualizado el sistema operativo para un mejor rendimiento y seguridad.</div>";
  tips +=
    "<div class='tip'><strong>Uso de cargadores adecuados:</strong> Emplea siempre cargadores oficiales o recomendados por el fabricante.</div>";
  tips +=
    "<div class='tip'><strong>Limpieza regular:</strong> Limpia la pantalla y el cuerpo del dispositivo para evitar acumulación de suciedad.</div>";

  // Tips según el año de lanzamiento
  if (year < 2015) {
    tips +=
      "<div class='tip'><strong>Dispositivo antiguo:</strong> Considera optimizar el rendimiento y revisar la compatibilidad de las apps actuales.</div>";
  } else {
    tips +=
      "<div class='tip'><strong>Dispositivo reciente:</strong> Configura adecuadamente las aplicaciones para mantener un buen desempeño.</div>";
  }

  // Tips según la capacidad de la batería
  if (battery < 2000) {
    tips +=
      "<div class='tip'><strong>Batería de baja capacidad:</strong> Evita ciclos de carga extremos y protege el dispositivo del sobrecalentamiento.</div>";
  } else {
    tips +=
      "<div class='tip'><strong>Batería de mayor capacidad:</strong> Aunque tengas más mAh, no olvides evitar cargas prolongadas y temperaturas extremas.</div>";
  }

  // Tips según la gama del dispositivo
  if (range === "alta") {
    tips +=
      "<div class='tip'><strong>Dispositivo de gama alta:</strong> Cuida especialmente la pantalla y los componentes delicados, utilizando fundas y protectores de pantalla.</div>";
  } else if (range === "baja") {
    tips +=
      "<div class='tip'><strong>Dispositivo de gama baja:</strong> Optimiza el uso de recursos cerrando apps innecesarias y manteniendo el sistema limpio.</div>";
  }

  // Recomendación general según la marca
  tips +=
    "<div class='tip'><strong>Consejo de " +
    brand +
    ":</strong> Consulta la guía del fabricante para obtener recomendaciones específicas sobre el cuidado y mantenimiento de tu dispositivo.</div>";

  // Mostrar los tips en la página
  tipsDiv.innerHTML = tips;
});

document.addEventListener("DOMContentLoaded", function () {
  const form = document.getElementById("deviceForm");
  if (!form) {
    console.error("Device form not found!");
    return;
  }

  form.addEventListener("submit", function (e) {
    e.preventDefault();

    const tipsDiv = document.getElementById("tips");
    if (!tipsDiv) {
      console.error("Tips div not found!");
      return;
    }

    // Rest of your existing form handling code...
  });
});

function ingreso() {
  window.location.href = "../login/login.html";
}
function overlaybutton() {
  window.location.href = "../vista/vista.html";
}
