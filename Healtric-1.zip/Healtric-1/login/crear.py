import sqlite3

# Conectar a la base de datos (se creará si no existe)
conn = sqlite3.connect('usuarios.db')

# Crear un cursor
cur = conn.cursor()

# Crear una tabla para almacenar los valores
cur.execute('''
    CREATE TABLE IF NOT EXISTS datos (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        userName TEXT UNIQUE,
        userEmail TEXT,
        userPassword TEXT
    )
''')

# Confirmar los cambios y cerrar la conexión
conn.commit()
conn.close()

print("Base de datos y tabla creadas correctamente.")