const btnSignIn = document.getElementById("sign-in");
const btnSignUp = document.getElementById("sign-up");
const containerFormRegister = document.getElementById("container-form-register");
const containerFormLogin = document.getElementById("container-form-login");
const loginForm = document.getElementById("form-login");
const registerForm = document.getElementById("form-register");
const loginError = document.getElementById("login-error");

btnSignIn.addEventListener("click", e => {
    containerFormRegister.classList.add("spin");
    setTimeout(() => {
        containerFormRegister.classList.remove("spin");
        containerFormRegister.classList.add("hide");
        containerFormLogin.classList.remove("hide");
    }, 400);
});

btnSignUp.addEventListener("click", e => {
    containerFormLogin.classList.add("spin");
    setTimeout(() => {
        containerFormLogin.classList.remove("spin");
        containerFormLogin.classList.add("hide");
        containerFormRegister.classList.remove("hide");
    }, 400);
});

// Registro
registerForm.addEventListener('submit', (e) => {
    e.preventDefault();
    const userName = document.getElementById('userName').value;
    const userEmail = document.getElementById('userEmail').value;
    const userPassword = document.getElementById('userPassword').value;

    fetch('http://127.0.0.1:5000/register', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({
            userName,
            userEmail,
            userPassword
        })
    })
    .then((response) => response.json())
    .then((data) => {
        console.log(data);
        if (data.message) {
            alert(data.message);
        } else if (data.error) {
            alert(data.error);
        }
    })
    .catch((error) => console.error(error));
});

// Login
loginForm.addEventListener('submit', (e) => {
    e.preventDefault();
    const userName = document.getElementById('user').value;
    const userPassword = document.getElementById('userPass').value;

    fetch('http://127.0.0.1:5000/login', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({
            userName,
            userPassword
        })
    })
    .then((response) => response.json())
    .then((data) => {
        console.log(data);
        if (data.message) {
            alert(data.message);
            window.location.href = "../principal/principal.html";
        } else if (data.error) {
            loginError.textContent = "Usuario o contraseña incorrectos, intenta de nuevo.";
            loginError.style.display = "block";
        }
    })
    .catch((error) => {
        console.error('Hay un problema con la operación fetch:', error);
        loginError.textContent = "Usuario o contraseña incorrectos, intenta de nuevo.";
        loginError.style.display = "block";
    });
});