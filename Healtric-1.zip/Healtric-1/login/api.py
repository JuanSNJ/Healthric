from flask import Flask, request, jsonify
from flask_cors import CORS
import sqlite3

app = Flask(__name__)
CORS(app)

def get_db_connection():
    conn = sqlite3.connect('usuarios.db')
    conn.row_factory = sqlite3.Row  # Esto facilita trabajar con resultados como diccionarios
    return conn

@app.route('/register', methods=['POST'])
def register():
    if request.method == 'POST':
        try:
            post_data = request.get_json()
            name = post_data['userName']
            email = post_data['userEmail']
            password = post_data['userPassword']

            conn = get_db_connection()
            cursor = conn.cursor()
            cursor.execute("INSERT INTO datos (userName, userEmail, userPassword) VALUES (?, ?, ?)", (name, email, password))
            conn.commit()
            conn.close()

            return jsonify({"message": "Te has registrado correctamente!"})
        except Exception as e:
            return jsonify({"error": str(e)})

@app.route('/login', methods=['POST'])
def login():
    if request.method == 'POST':
        try:
            post_data = request.get_json()
            name = post_data['userName']
            password = post_data['userPassword']

            conn = get_db_connection()
            cursor = conn.cursor()
            cursor.execute("SELECT * FROM datos WHERE userName=? AND userPassword=?", (name, password))
            user = cursor.fetchone()
            conn.close()

            if user:
                return jsonify({"message": "Sesión iniciada correctamente!"})
            else:
                return jsonify({"error": "¡Tu usuario o contraseña son incorrectos!"})
        except Exception as e:
            return jsonify({"error": str(e)})

if __name__ == '__main__':
    app.run(debug=True)


